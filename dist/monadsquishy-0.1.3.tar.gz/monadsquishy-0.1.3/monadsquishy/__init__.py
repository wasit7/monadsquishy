# monadsquishy/__init__.py
from . import functions as sf
from .squishy import Squishy