# Squishy

Squishy is a Python package for data transformation using the Monad pattern and cleansing operations.

## Installation

### From PyPI:

```bash
pip install monadsquishy
```

### From github
```bash
pip install git+https://github.com/wasit7/monadsquishy.git
```
